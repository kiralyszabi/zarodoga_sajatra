 /*       // Előre megadott felhasználónév és jelszó
        const helyesFelhasznaloNev = "admin";
        const helyesJelszo = "admin123";

        // Bejelentkezési függvény
        function bejelentkezes() {
            // Lekérjük a felhasználónév és jelszó mező értékeit
            const felhasznaloNev = document.getElementById("adminnev").value;
            const jelszo = document.getElementById("adminjelszo").value;
            
            // Ellenőrizzük, hogy a felhasználónév és jelszó helyes-e
            if (felhasznaloNev === helyesFelhasznaloNev && jelszo === helyesJelszo) {
                // Ha stimmel, bezárjuk a modált
                closeModal();
            } else {
                // Ha nem stimmel, visszajelzést adunk
                document.getElementById("visszajelzesadmin").innerHTML = "Hibás felhasználónév vagy jelszó!";
                document.getElementById("visszajelzesadmin").style.color = "red";
            }
        }

        // A modál bezárása
        function closeModal() {
            const modal = document.getElementById("myModal");
            modal.style.display = "none"; // Elrejtjük a modált
        }

        // Amikor az oldal betöltődik, megjelenítjük a modált
        window.onload = function() {
            const modal = document.getElementById("myModal");
            modal.style.display = "block"; // Modál megjelenítése
        };*/



        fetch("http://localhost:3000/adatokLista")
        .then(x => x.json())
        .then(y => megjelenit(y))
    
    
    function megjelenit(y) {
        console.log(y)
        for (const elem of y) {
            document.getElementById("osszes").innerHTML += `
            <div class="col-sm-12">
            <div class="osszesadat">
            <span style="font-weight:bold;font-size: 25px;">${elem.vnev}</span>
            <br>
            <span style="font-style:italic;font-size: 18px;">${elem.helyszin_nev}</span>
            <br>
            ${elem.nev}
            <br>
            <span style="text-decoration:underline;">${elem.datum}</span>
            <br>
            ${elem.leiras} ...
            </div>
        </div>
        
            `
    
        }
    
    
    }