function kapcsolatfelvitel() {
    


    const datum = new Date();
   
   const dateString =datum.getFullYear() + "-" + (datum.getMonth() + 1) + "-" + datum.getDate()
    
    var adatok = {
        "bevitel1": document.getElementById("bevitel1").value,
        "bevitel2": document.getElementById("bevitel2").value,
        "bevitel3": document.getElementById("bevitel3").value,
        "datum": dateString  // A mai dátum hozzáadása

    }

    if (document.getElementById("bevitel1").value == "" || document.getElementById("bevitel2").value == "" || document.getElementById("bevitel3").value == "") {
        document.getElementById("visszajelzes").innerHTML = "Minden mezőt ki kell tölteni!";
        document.getElementById("visszajelzes").style.color = "red";  // Hibás üzenet
    } else {
        // Ha minden mező ki van töltve, akkor küldd el az üzenetet

        fetch("http://localhost:3000/kapcsolatfelvitel", {
        method: "POST",
        body: JSON.stringify(adatok),
        headers: { "Content-type": "application/json; charset=UTF-8" }
    })
        .then(x => x.text())
        .then(y => {
           document.getElementById("visszajelzes").innerHTML = y
            
        })
    }


    
        
}