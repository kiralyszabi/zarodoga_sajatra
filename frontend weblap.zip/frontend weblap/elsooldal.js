

function adminoldalra(){
    window.location.href = "adminfooldal.html";
}



fetch("http://localhost:3000/varosnevek")
    .then(x => x.json())
    .then(y => megjelenit(y))


function megjelenit(y) {
    console.log(y)
    for (const elem of y) {
        document.getElementById("varosok").innerHTML += `
           <option value="">${elem.vnev}</option> 
        `

    }


}


 // Egyedi beállítások, hogy gyorsabb legyen a váltás
 var carousel = new bootstrap.Carousel(document.querySelector('#carouselExample'), {
    interval: 4000, // 5 másodperc
    ride: 'carousel', // Automatikus forgatás engedélyezése
    pause: 'hover' // Megállítja, ha az egér a képen van
});



