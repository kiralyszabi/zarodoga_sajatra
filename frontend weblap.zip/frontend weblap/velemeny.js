fetch("http://localhost:3000/megjelenituzenetek")
    .then(x => x.json())
    .then(v => megjelenit(v))


function megjelenit(v) {
    console.log(v)
    for (const elem of v) {
        document.getElementById("elfogadvavelemenyek").innerHTML += `
                <div class="col-sm-4">
                <div class="formazas">
                <br>
                <i>"${elem.elfogadva_uzenet}"</i>
                <br>
                <strong>-${elem.elfogadva_nev}-</strong>
                </div>  
            </div>

    `

    }


}